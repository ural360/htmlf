﻿namespace MelonLoader
{
    public static class BuildInfo
    {
        public const string Name = "MelonLoader";
        public const string Description = "MelonLoader";
        public const string Author = "Lava Gang";
        public const string Company = "discord.gg/2Wn3N2P";
        public const string Version = "0.6.2";
    }
}