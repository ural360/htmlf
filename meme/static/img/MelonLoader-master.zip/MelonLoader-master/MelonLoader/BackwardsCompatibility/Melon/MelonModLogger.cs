﻿using System;

namespace MelonLoader
{
    [Obsolete("MelonLoader.MelonModLogger is Only Here for Compatibility Reasons. Please use MelonLoader.MelonLogger instead.")]
    public class MelonModLogger : MelonLogger { }
}