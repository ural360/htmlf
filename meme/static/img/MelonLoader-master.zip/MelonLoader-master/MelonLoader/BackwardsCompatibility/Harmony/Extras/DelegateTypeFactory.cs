﻿namespace Harmony
{
	public class DelegateTypeFactory : HarmonyLib.DelegateTypeFactory { }
}