﻿using System;

namespace Harmony
{
	[Obsolete("Harmony.Priority is Only Here for Compatibility Reasons. Please use HarmonyLib.Priority instead.")]
	public static class Priority
	{
		[Obsolete("Harmony.Priority.Last is Only Here for Compatibility Reasons. Please use HarmonyLib.Priority.Last instead.")]
		public const int Last = HarmonyLib.Priority.Last;
		[Obsolete("Harmony.Priority.VeryLow is Only Here for Compatibility Reasons. Please use HarmonyLib.Priority.VeryLow instead.")]
		public const int VeryLow = HarmonyLib.Priority.VeryLow;
		[Obsolete("Harmony.Priority.Low is Only Here for Compatibility Reasons. Please use HarmonyLib.Priority.Low instead.")]
		public const int Low = HarmonyLib.Priority.Low;
		[Obsolete("Harmony.Priority.LowerThanNormal is Only Here for Compatibility Reasons. Please use HarmonyLib.Priority.LowerThanNormal instead.")]
		public const int LowerThanNormal = HarmonyLib.Priority.LowerThanNormal;
		[Obsolete("Harmony.Priority.Normal is Only Here for Compatibility Reasons. Please use HarmonyLib.Priority.Normal instead.")]
		public const int Normal = HarmonyLib.Priority.Normal;
		[Obsolete("Harmony.Priority.HigherThanNormal is Only Here for Compatibility Reasons. Please use HarmonyLib.Priority.HigherThanNormal instead.")]
		public const int HigherThanNormal = HarmonyLib.Priority.HigherThanNormal;
		[Obsolete("Harmony.Priority.High is Only Here for Compatibility Reasons. Please use HarmonyLib.Priority.High instead.")]
		public const int High = HarmonyLib.Priority.High;
		[Obsolete("Harmony.Priority.VeryHigh is Only Here for Compatibility Reasons. Please use HarmonyLib.Priority.VeryHigh instead.")]
		public const int VeryHigh = HarmonyLib.Priority.VeryHigh;
		[Obsolete("Harmony.Priority.First is Only Here for Compatibility Reasons. Please use HarmonyLib.Priority.First instead.")]
		public const int First = HarmonyLib.Priority.First;
	}
}