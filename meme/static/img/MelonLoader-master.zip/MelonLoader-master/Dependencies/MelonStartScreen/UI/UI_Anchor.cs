﻿namespace MelonLoader.MelonStartScreen.UI
{
    internal enum UI_Anchor
    {
        // Upper
        UpperLeft,
        UpperCenter,
        UpperRight,

        // Middle
        MiddleLeft,
        MiddleCenter,
        MiddleRight,

        // Lower
        LowerLeft,
        LowerCenter,
        LowerRight
    }
}
