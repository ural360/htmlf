﻿namespace Windows
{
    internal struct Point
    {
        public int x;
        public int y;
    }
}
