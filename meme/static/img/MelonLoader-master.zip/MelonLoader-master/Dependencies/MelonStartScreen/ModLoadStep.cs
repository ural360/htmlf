﻿namespace MelonLoader.MelonStartScreen
{
    internal enum ModLoadStep
    {
        Generation,
        LoadMelons,
        InitializeMelons,
        OnApplicationStart
    }
}
